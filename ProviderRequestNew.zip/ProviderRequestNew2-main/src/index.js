import React from "react";
import ReactDOM from "react-dom/client";
import "./App.css";
// import "../src/css/providerrequest.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import { ProviderRequest } from "./Components/Main";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import reducer from "./Store/Reducer";
import reportWebVitals from "./reportWebVitals";

const store = configureStore({
  reducer,
});
console.log("Mount");
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  // <React.StrictMode>
  <Provider store={store}>
    <ProviderRequest />
  </Provider>
  // </React.StrictMode>
);

reportWebVitals();
