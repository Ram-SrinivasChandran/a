import { createSelector } from "reselect";

const SelectAppState = (state) => state;

//Memoizzed selector
export const getMemoizedState = createSelector(
  [SelectAppState],
  (SelectAppState) => ({
    IsReadOnlyMode: SelectAppState.IsReadOnlyMode,
    Toast: SelectAppState.Toast,
    CallId: SelectAppState.CallId,
    IsAutoCallStop: SelectAppState.IsAutoCallStop,
    requestForm: SelectAppState.RequestForm,
    CurrentScreen: SelectAppState.CurrentScreen,
    ActiveQuery: SelectAppState.RequestForm.ActiveQuery,
    ShowCurrentCallRequests: SelectAppState.ShowCurrentCallRequests,
    SelectedRequestId: SelectAppState.RequestForm.RequestId,
    callHistory: SelectAppState.RequestForm.CallHistory,
    CurrentCallRequests: SelectAppState.CurrentCallRequests,
    WindowHeight: SelectAppState.WindowHeight,
    MasterData: SelectAppState.MasterData,
    ShowLoader: SelectAppState.ShowLoader,
    CallerInformation: SelectAppState.CallerInformation,
    PreviousQueryDetails: SelectAppState.PreviousQueryDetails,
    queryDetails: SelectAppState.QueryDetails,
    SearchParameters: SelectAppState.SearchParameters,
    GridDataLoadingId: SelectAppState.GridDataLoadingId,
    ConfirmationDialog: SelectAppState.ConfirmationDialog,
    ResultCount: SelectAppState.ResultCount,
    isClicked: SelectAppState.isClicked,
    IsOpenEditor: SelectAppState.IsOpenEditor,
  })
);
