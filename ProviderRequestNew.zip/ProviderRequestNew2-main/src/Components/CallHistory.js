import { useDispatch, useSelector } from "react-redux";
import { getMemoizedState } from "../Store/Selectors";
import { RequestModeIcon, ScreenType } from "../Store/Constants";
import { Util } from "../Common/Actions/Util";
import { ActionTypes } from "../Store/Constants";
import { useState, useEffect } from "react";
// import "../css/sample.css";
import "../css/providerrequest.css";

export const CallHistory = ({ callHistory, onRowSelected }) => {
  const [filteredCallHistory, setFilteredCallHistory] = useState([]);

  const { CurrentScreen, ShowCurrentCallRequests, SelectedRequestId } =
    useSelector(getMemoizedState);

  // console.log("History: ", ShowCurrentCallRequests);

  const dispatch = useDispatch();

  const actions = {
    updateScreenState: (screen) => {
      dispatch({ type: ActionTypes.UPDATE_SCREENSTATE, screen });
    },
  };

  const onCloseCallHistory = () => {
    console.log("OncloseCallHistory");
    if (CurrentScreen == ScreenType.GridWithCurrentRequests) {
      console.log("current request grid");
      actions.updateScreenState(ScreenType.Grid);
    } else {
      console.log("Edit form screen");
      actions.updateScreenState(ScreenType.EditForm);
    }
  };

  useEffect(() => {
    const previousCallId = "";

    const sortedCallHistory = callHistory?.sort(
      (a, b) => new Date(a.AttendedAt) - new Date(b.AttendedAt)
    );

    const filteredCallHistory = !ShowCurrentCallRequests
      ? sortedCallHistory?.filter(
          (item) => item.RequestId !== SelectedRequestId
        )
      : sortedCallHistory;

    if (filteredCallHistory) {
      filteredCallHistory.map((callHistory) => {
        callHistory.PreviousCallId = previousCallId;
        previousCallId = callHistory.ProviderCall_Id;
      });
    }

    setFilteredCallHistory(filteredCallHistory);
  }, [callHistory, ShowCurrentCallRequests, SelectedRequestId]);

  return (
    <div
      id="rightPane_psq_view_callhistory"
      style={
        CurrentScreen == ScreenType.AddFormWithHistory ||
        CurrentScreen == ScreenType.EditFormWithHistory ||
        CurrentScreen == ScreenType.GridWithCurrentRequests
          ? { width: "42.5%", marginRight: "-98.5%" }
          : { width: "0", marginRight: "-1px" }
      }
    >
      <div className="sticky_head col-md-12 p0">
        <div className="col-md-6 pad10">
          <p className="serv-titlepsq">
            <strong>
              <img
                src={
                  ShowCurrentCallRequests
                    ? "/content/images/Current call requests.png"
                    : "/content/images/Call history.png"
                }
                alt=""
              />
              {ShowCurrentCallRequests
                ? "Current Call Requests"
                : "Call History"}
            </strong>
          </p>
        </div>
        <div className="col-md-6 pad10 rightCloseBtn_closehistory">
          <button
            onClick={onCloseCallHistory}
            // className="closeicon glyphicon glyphicon-remove-circle pull-right"
          >
            close
          </button>
        </div>
      </div>
      <div className="col-md-12">
        <ul
          className={
            "timeline" + (ShowCurrentCallRequests ? "currentcall" : "")
          }
        >
          {filteredCallHistory?.map((callHistory) => (
            <li
              key={callHistory.Id}
              className={
                "timeline-item bg-white rounded ml-3 p-4 shadow" +
                (!callHistory.ProviderCall_Id ||
                callHistory.ProviderCall_Id != callHistory.PreviousCallId
                  ? ""
                  : "same call")
              }
            >
              <div>
                <p className="det_card_header">
                  <img
                    src={RequestModeIcon.get(callHistory.RequestMode)}
                    alt="request mode"
                    className="Icnclr"
                  />
                  <span className="serv_request">
                    {Util.getCustomDateTimeFormat(callHistory.AttendedAt)}
                  </span>
                  <span className="pull-right ronlytxt">
                    {callHistory.RequestId}
                  </span>
                </p>
              </div>
              <div className="detailsCard">
                <h3 className="detailsCardheader">
                  {callHistory.RequestTypeName}
                  <span className="pull-right ronlytxt">
                    {callHistory.AttendedByFullName}
                  </span>
                </h3>
                <div className="detailscardbody">
                  <div className="col-md-12 p0">
                    <p className="txtQuery">
                      <span className="Icnclr">
                        <img
                          className="v_align_bot"
                          src="/content/images/query.png"
                          alt=""
                        />
                      </span>
                      {callHistory.Query}
                    </p>
                  </div>
                  <div className="col-md-1">
                    <p
                      className="Editinc"
                      data-toggle="modal"
                      data-target="#tblhtritpane"
                      onClick={() => onRowSelected(callHistory?.RequestId)}
                    >
                      <span className="glyphicon glyphicon-edit"></span>
                    </p>
                  </div>
                </div>
                <p className="txtResponse">
                  <span className="Icnclr">
                    <img
                      className="v_align_bot"
                      src="/content/images/response.png"
                      alt=""
                    />
                  </span>
                  {callHistory.Response}
                </p>
                <p className="verified">
                  {callHistory.VerifiedUsing ? (
                    <span className="verifiedicn glyphicon glyphicon-ok-sign mRight5"></span>
                  ) : (
                    ""
                  )}
                  {callHistory.VerifiedUsing}
                </p>
                {!callHistory.UpdatedByFullName || !callHistory.UpdatedAt ? (
                  ""
                ) : (
                  <p className="updatedet">
                    {" "}
                    Last Updated by:{" "}
                    <span className="bluetxt">
                      {Util.getCustomDateTimeFormat(callHistory.UpdatedAt)}
                    </span>
                  </p>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
