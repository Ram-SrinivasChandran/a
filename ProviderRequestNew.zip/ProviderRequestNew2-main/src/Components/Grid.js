import {
  createContext,
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {
  ColumnDirective,
  ColumnsDirective,
  GridComponent,
  Reorder,
  Inject,
  Sort,
  Filter,
  Edit,
  Toolbar,
  Resize,
  VirtualScroll,
  ExcelExport,
  gridHeader,
} from '@syncfusion/ej2-react-grids'
import '../Common/css/SyncfusionGridCustom.css'
import axios from 'axios'
import { ActionTypes, ScreenType } from '../Store/Constants'
import {
  GetFormattedFileName,
  GetFormattedDateTime,
} from '../Common/Actions/DateHandler'
import { getMemoizedState } from '../Store/Selectors'
import { FilterRow } from './FilterRow'
import { type } from '@testing-library/user-event/dist/type'

export const Grid = forwardRef((props, ref) => {
  console.log('PROPS:', props)
  const { onRowSelected } = props
  console.log('rows::', onRowSelected)
  const [gridHeight, setGridHeight] = useState(window.innerHeight - 345)
  const [gridData, setGridData] = useState([])

  const prevCurrentScreenRef = useRef(null)
  const gridRef = useRef(null)
  const { CurrentScreen, requestForm } = useSelector(getMemoizedState)

  const dispatch = useDispatch()

  const actions = {
    updateSearchStatus: (isSearchInProgress, resultCount = null) =>
      dispatch({
        type: ActionTypes.UPDATES_SEARCHSTATUS,
        payload: { isSearchInProgress, resultCount },
      }),
  }

  const filterSettings = {
    immediateModeDelay: 300,
    mode: 'Immediate', // to show search result immidiately
  }

  const updateGridHeight = () => {
    setGridHeight(window.innerHeight - 345)
  }

  //COMPONENTDIDMOUNT() + COMPONENTWILLUNMOUNT
  useEffect(() => {
    window.addEventListener('resize', updateGridHeight)
    return () => {
      window.removeEventListener('resize', updateGridHeight)
    }
  }, [updateGridHeight])

  const databound = () => {
    console.log('Databound !!')

    try {
      if (gridRef.current) {
        console.log('Databound:', gridRef.current)
        const columns = gridRef.current.getColumns()
        console.log('Columns:', columns)
        if (columns) {
          columns.forEach((column) => {
            console.log('Get columns worked!')
            if (column && column.type === 'string') {
              if (!column.filter) {
                column.filter = {}
              }
              column.filter.operator = 'contains'
            }
          })
        }
      }
    } catch {
      console.log('Error occured in databound!')
    }
  }

  //COMPONENTDIDUPDATE()
  useEffect(() => {
    // console.log('LOADSEARCH METHOD CALLED...')

    if (CurrentScreen !== prevCurrentScreenRef.current) {
      gridRef.current.refresh()
      console.log('Evil')
    }
    prevCurrentScreenRef.current = CurrentScreen
  }, [CurrentScreen])

  useEffect(() => {
    if (window.RequestData.GridData && window.RequestData.GridData.length) {
      console.log('Data:', window.RequestData.GridData)
      setGridData(window.RequestData.GridData)
      setDateFormat(window.RequestData.GridData)
    }
  }, [window.RequestData.GridData])

  const setDateFormat = (gridData) => {
    try {
      gridData.map((d) => {
        d.RequestedAt = d.RequestedAt
          ? GetFormattedDateTime(new Date(d.RequestedAt))
          : ''
      })
    } catch {
      console.log('Error!')
    }
  }

  useImperativeHandle(ref, () => {
    return {
      loadSearchData(searchParam, dispatch) {
        console.log('LOADSEARCH METHOD CALLED...')
        let apiRootUrl = window.ApiRootUrl ? window.ApiRootUrl : ''
        let urlString = `${apiRootUrl}/ProviderRequest/GetProviderRequests`
        if (window.IsConnected === true) {
          actions.updateSearchStatus(dispatch, true)
          let data = {
            FromDate: searchParam.FromDate.Value,
            ToDate: searchParam.ToDate.Value,
            StatusIds: searchParam.StatusIds,
            Channels: searchParam.Channels?.join(','),
            ClientId: searchParam.Client.Value,
            AuditIds: searchParam.AuditIds.Value,
          }
          axios.post(urlString, data).then(
            (response) => {
              if (response.data != null && response.data != undefined) {
                //Convert server date format to js date object
                setDateFormat(response.data)
                setGridData(response.data)
                actions.updateSearchStatus(
                  dispatch,
                  false,
                  response.data.length,
                )
              } else {
                //For custom error page
                handleSearchError(response, dispatch)
              }
            },
            (e) => {
              handleSearchError(e, dispatch)
            },
          )
        }
      },
    }
  })

  // const loadSearchDataRef = useRef(null);

  // useEffect((searchParam) => {
  //   loadSearchDataRef.current = loadSearchData(searchParam, dispatch);
  // }, []);

  // if (props.grid_Ref?.current) {
  //   props.grid_Ref.current = {
  //     loadSearchData: loadSearchData(),
  //   };
  // } else {
  //   console.log("Error");
  // }

  //Instead of export method - exportData
  // const exportData = () => {
  //   console.log("Export Data");
  //   if (gridRef.current && gridRef.current.columns[0]) {
  //     for (let i = 0; i < gridRef.current.columns.length; i++) {
  //       gridRef.current.columns[i].previousVisible =
  //         gridRef.current.columns[i].visible;
  //       gridRef.current.columns[i].visible = true;
  //     }
  //     gridRef.current.columns[0].visible = false; //To hide action column while export
  //   }
  //   var date = new Date();
  //   let excelExportProperties = {
  //     fileName: GetFormattedFileName("ProviderRequest_", ".xlsx"),
  //   };
  //   gridRef.current.excelExport(excelExportProperties);
  // };

  // const excelExportComplete = () => {
  //   console.log("Export Complete");
  //   if (gridRef.current && gridRef.current.columns[0]) {
  //     for (let i = 0; i < gridRef.current.columns.length; i++) {
  //       gridRef.current.columns[i].visible =
  //         gridRef.current.columns[i].previousVisible;
  //     }
  //   }
  // };

  const handleSearchError = (e, dispatch) => {
    try {
      console.log('Handle search error')
      window.alert('System failed to fetch data. Please contact support team.')
      window.console.error(e)
      actions.updateSearchStatus(dispatch, false)
    } catch {
      console.log('error')
    }
  }

  //   const databound = () => {
  //     console.log("Databound !!");
  //     if (gridRef.current) {
  //       console.log("Databound:", gridRef.current);
  //       //this.grid.columns=GridColumns;
  //       /*free search with contains is allowed on string type columns as per ej2*/
  //       gridRef.current.getColumns().forEach((column) => {
  //         console.log("Get columns worked!");
  //         if (column.type === "string") {
  //           if (column.filter === undefined) {
  //             column.filter = {};
  //           }
  //           column.filter.operator = "contains";
  //         }
  //         // return column;
  //       });
  //     }
  //   };

  const recordDoubleClick = (args) => {
    if (onRowSelected) {
      onRowSelected(args.rowData.Id)
      console.log('args:', args.rowData.Id)
    }
  }

  /** Custom comparer function */
  const dateSortComparer = (reference, comparer) => {
    console.log('Datesort')
    try {
      if (reference !== '' && comparer !== '') {
        if (new Date(reference) < new Date(comparer)) {
          return -1
        }
        if (new Date(reference) > new Date(comparer)) {
          return 1
        }
      } else if (reference !== '' && comparer === '') {
        return 1
      } else if (reference === '' && comparer !== '') {
        return -1
      }
      return 0
    } catch {
      console.log('Error!')
    }
  }

  const numericSorter = (reference, comparer) => {
    console.log('Numericsort')

    try {
      if (reference && comparer) {
        if (+reference < +comparer) {
          return -1
        }
        if (+reference > +comparer) {
          return 1
        }
        if (+reference == +comparer) {
          return -1
        }
      } else if (reference && !comparer) {
        return 1
      } else if (!reference && comparer) {
        return -1
      }
    } catch {
      console.log('Error!!')
    }
  }

  return (
    <>
      <div
        className="tblht"
        style={{
          width:
            CurrentScreen == ScreenType.Grid
              ? '100%'
              : CurrentScreen == ScreenType.AddForm ||
                CurrentScreen == ScreenType.EditForm
              ? '37.5%'
              : CurrentScreen == ScreenType.GridWithCurrentRequests
              ? '55.5%'
              : '0',
        }}
      >
        <div className="grey-bg2 show" id="psq_main">
          <GridComponent
            dataSource={gridData}
            height={gridHeight}
            enableVirtualization={true}
            //enableImmutableMode={true}
            ref={gridRef}
            allowPaging={false}
            gridLines="Both"
            allowSorting={true}
            allowResizing={true}
            allowReordering={true}
            allowFiltering={true}
            allowExcelExport={true}
            filterSettings={filterSettings}
            dataBound={databound}
            // excelExportComplete={excelExportComplete}
            recordDoubleClick={recordDoubleClick}
            clipMode="EllipsisWithTooltip"
          >
            <ColumnsDirective>
              <ColumnDirective
                field="Action"
                headerText="Action"
                allowFiltering={false}
                allowSorting={false}
                width="70"
                textAlign="Center"
                allowReordering={false}
                template={(props) => (
                  <button
                    // className="glyphicon glyphicon-edit"
                    onClick={() => {
                      if (onRowSelected) {
                        onRowSelected(props?.Id)
                      }
                    }}
                  ></button>
                )}
              />
              <ColumnDirective
                field="Id"
                headerText="Request Id"
                width="80"
                type="string"
                isPrimaryKey={true}
                sortComparer={numericSorter}
              />
              <ColumnDirective
                field="CapName"
                headerText="Client Audit Program"
                width="180"
                type="string"
              />
              <ColumnDirective
                // field="FlowName"
                field="Flow"
                headerText="Flow"
                width="150"
                type="string"
              />
              <ColumnDirective
                field="AuditId"
                headerText="Audit Id"
                width="80"
                type="string"
                template={(props) =>
                  props.AuditId === 0 ? null : <span> {props.AuditId} </span>
                }
                sortComparer={numericSorter}
              />
              <ColumnDirective
                field="AdditionalAuditIds"
                headerText="Additional Audit Ids"
                width="150"
                type="string"
                textAlign="Center"
              />
              <ColumnDirective
                // field="Channels"
                field="ChannelName"
                headerText="Channel"
                width="100"
                type="string"
                textAlign="Center"
              />
              <ColumnDirective
                // field="RequestedAt"
                field="RequestDate"
                headerText="Request Date"
                width="110"
                sortComparer={dateSortComparer}
                visible={CurrentScreen == ScreenType.Grid}
              />
              <ColumnDirective
                field="RequestTypeName"
                headerText="Request Type"
                width="150"
                type="string"
                visible={CurrentScreen == ScreenType.Grid}
              />
              <ColumnDirective
                field="CallerName"
                headerText="User / Caller Name"
                width="150"
                type="string"
                visible={CurrentScreen == ScreenType.Grid}
              />
              <ColumnDirective
                field="AttendedBy"
                headerText="Inbound Request Recipient"
                width="150"
                type="string"
              />
              <ColumnDirective
                field="StatusName"
                headerText="Status"
                width="100"
                type="string"
                textAlign="Center"
                template={(props) => (
                  <span
                    className={`${
                      props.StatusCode === 'NEW'
                        ? 'statusNew'
                        : props.StatusCode === 'UNRESOLVED'
                        ? 'statusWIP'
                        : props.StatusCode === 'REOPENED'
                        ? 'statusReopen'
                        : 'statusRes'
                    } status-width`}
                  >
                    {props.StatusName}{' '}
                  </span>
                )}
              />
            </ColumnsDirective>
            <Inject
              services={[
                Sort,
                Filter,
                Toolbar,
                Edit,
                VirtualScroll,
                Reorder,
                Resize,
                ExcelExport,
              ]}
            />
          </GridComponent>
        </div>
      </div>
      {/* <FilterRow method={loadSearchData()} /> */}
    </>
  )
})

// Forwarding the ref to access openEditor method
// export default forwardRef((props, ref) => {
//   <Grid {...props} ref={ref} />;
// });
