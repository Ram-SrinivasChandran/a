import { useEffect, useRef, useCallback, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { ActionTypes, ScreenType } from '../Store/Constants'
import { ToastProps } from '../Common/Constants/CommonConstants'
import { ToastComponent } from '@syncfusion/ej2-react-notifications'
import { CallTracker } from './CallTracker'
import { getMemoizedState } from '../Store/Selectors'
import { CallHistory } from './CallHistory'
import { RequestForm } from './RequestForm'
import PopUpTextEditor from '../Common/Components/PopUpTextEditor'
import { CustomDialog } from './CustomDialog'
import { FilterRow } from './FilterRow'
import { Grid } from './Grid'
import { Actions } from '../Store/Actions.js'
export const ProviderRequest = () => {
  const {
    Toast,
    IsReadOnlyMode,
    requestForm,
    CallId,
    CurrentScreen,
    ShowCurrentCallRequests,
    callHistory,
    CurrentCallRequests,
    ShowLoader,
    ConfirmationDialog,
    ResultCount,
    SearchParameters,
  } = useSelector(getMemoizedState)

  const dispatch = useDispatch()

  const actions = {
    updateWindowSize: () => {
      dispatch({
        type: ActionTypes.UPDATE_WINDOWSIZE,
        payload: { height: window.innerHeight, width: window.innerWidth },
      })
    },
    initServerCall: (data) =>
      dispatch({
        type: ActionTypes.INIT_SERVERCALL,
        payload: {
          action: ActionTypes.GET_PROVIDER_REQUEST_DETAILS,
          data: data,
        },
      }),
    onPopUpEditorValueChange: (parameter, data) => {
      dispatch({
        type: parameter.actionType,
        payload: { field: parameter.field, data: data },
      })
    },
  }

  // const beforeunload = (e) => {
  //   console.log("Before unload method called!!");
  //   // ERROR: UNCAUGHT TYPE ERROR: CANNOT SET PROPERITIES OF UNDEFINED(SETTING ' RETURNVALUE')
  // if (
  //   requestForm.HasChanges ||
  //   (requestForm.ActiveQuery.HasChanges &&
  //     CurrentScreen !== ScreenType.Grid) ||
  //   CallId !== ""
  // ) {
  // }
  // console.log(
  //   "Values from beforeunload method: ",
  //   requestForm.ActiveQuery.HasChanges,
  //   requestForm.HasChanges,
  //   CallId
  // );
  // e?.preventDefault();
  // e.returnValue = true;
  // };

  // //ComponentDidMount()
  useEffect(() => {
    if (window.RequestData) console.log('RequestData:', window.RequestData)
    dispatch({ type: ActionTypes.INIT_APP, payload: window.RequestData })
    if (window.IsConnected) {
      console.log('Server is Connected')
      dispatch({
        type: ActionTypes.INIT_CONNECTED,
        payload: window.IsConnected,
      })
    }

    window.addEventListener('resize', actions.updateWindowSize)
    return () => window.removeEventListener('resize', actions.updateWindowSize)
  }, [dispatch])

  // ---------------
  // if (window.RequestData) res = dispatch(actions.initApp(window.RequestData));
  // console.log("Init", res);
  // if (window.IsConnected) dispatch(actions.initConnected(window.IsConnected));
  // window.onresize = () => dispatch(actions.updateWindowSize())
  // if (window.docsument.querySelector("#glbMsgDiv"))
  //   dispatch((window.document.querySelector("#glbMsgDiv").innerHTML = ""));
  // window.addEventListener("beforeunload", beforeunload);

  // return () => {
  //   console.log("component Unmounted successfully");
  //   window.removeEventListener("beforeunload", beforeunload);

  // ComponentDidUnmount()
  // useEffect(() => {
  //   console.log("component Unmounted successfully");
  //   window.removeEventListener("beforeunload", beforeunload);
  // });
  // ----------------------

  //TO UNCOMMENT
  // -----------
  // useEffect(() => {
  //   const beforeunload = (e) => {
  //     if ((RequestForm.HasChanges || RequestForm.ActiveQuery.HasChanges) && CurrentScreen !== ScreenType.Grid || CallId !== "") {
  //       e.preventDefault();
  //       e.returnValue = true;
  //     }
  //   };

  //   window.addEventListener("beforeunload", beforeunload);
  //   return () => window.removeEventListener("beforeunload", beforeunload);
  // }, [RequestForm, CallId, CurrentScreen]);

  // const prevToastref = useRef(null);
  // const ToastObjRef = useRef(null);

  // //componentDidUpdate() -  UNCOMMENT
  // useEffect(() => {
  //   if (Toast?.Id !== prevToastref.current) {
  //     console.log("Toast Id" + Toast?.Id);
  //     prevToastref.current = Toast.Id;
  //     let toast = Toast;
  //     console.log("Toast:", toast);
  //     console.log(toast.Message);
  //     console.log(toast.Message.type);
  //     if (toast && toast.Message && toast.Message.type) {
  //       const messageType = toast?.Message.type;

  //       const msgObj = {
  //         ...ToastProps[messageType],
  //         content: toast?.Message.content,
  //       };
  //     }

  //     if (ToastObjRef.current) {
  //       ToastObjRef.current.hide("All");
  //       ToastObjRef.current.show(msgObj);
  //     }
  //   }
  // }, [Toast]);

  // const popUpEditorRef = useRef(null);
  const ref = useRef(null)
  const grid_Ref = useRef(null)

  const handleLoadSearchData = () => {
    // Check if the ref exists
    if (grid_Ref.current) {
      // Call the loadSearchdata method on the grid component using the ref
      grid_Ref.current.loadSearchData(SearchParameters, dispatch)
    }
  }

  const handleOpenEditor = (headerText, fieldValue, parameter) => {
    console.log('Received data from PopUpTextEditor:')
    console.log('HeaderText:', headerText)
    console.log('FieldValue:', fieldValue)
    console.log('Parameter:', parameter)
    if (ref.current) {
      ref.current.openEditor('headerText', 'fieldValue', {})
    }
  }
  return (
    <>
      <div className={window.ApiRootUrl ? 'mTop50' : ''}>
        {/* <ToastComponent
          ref={ToastObjRef}
          position={{ X: "Right" }}
          showCloseButton={true}
        ></ToastComponent> */}
        <div className="container-fluid" style={{ position: 'relative' }}>
          {!IsReadOnlyMode && <CallTracker />}
          {/* <FilterRow grid={() => grid_Ref.current.loadSearchData()} /> */}
          <FilterRow loadSearchData={handleLoadSearchData} />
          {/* <FilterRow methodCall={method} /> */}

          <Grid
            ref={grid_Ref}
            onRowSelected={actions.initServerCall}
            CurrentScreen={CurrentScreen}
          />
          <div className="row mar-pad-0">
            <div className="col-md-12">
              <span className="row-count">
                Total Number of Rows: {ResultCount}
              </span>
            </div>
          </div>
          <RequestForm openEditor={handleOpenEditor} />
          <CallHistory
            callHistory={
              !ShowCurrentCallRequests ? callHistory : CurrentCallRequests
            }
            onRowSelected={actions.initServerCall}
          />
        </div>
        <div className={'overlay' + (ShowLoader ? ' on' : '')}></div>
        <div
          className="loader"
          style={ShowLoader ? { display: 'block' } : {}}
        ></div>
        {/* <CustomDialog
          showDialog={ConfirmationDialog.visible}
          content={ConfirmationDialog.message}
          dispatch={dispatch}
        /> */}
        <PopUpTextEditor
          popUpKey="popupTextEditor"
          ref={ref}
          onValueUpdate={actions.onPopUpEditorValueChange}
          onOpenEditor={handleOpenEditor}
        />
      </div>
    </>
  )
}
