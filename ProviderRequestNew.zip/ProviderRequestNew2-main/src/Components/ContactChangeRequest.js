// import React from "react";
// import { Util } from "../Common/Actions/Util";
// import { Status } from "../Store/Constants";
// // import "../css/sample.css";
// import "../css/providerrequest.css";

// export const ContactChangeRequest = ({ queryDetail, statusCode }) => {
//   const OpenProviderAddressManager = () => {
//     var params = "/ProviderAddress/Show?";
//     var windowName = "EditProviderWindow";
//     var strWindowFeatures =
//       "menubar=no,location=no,resizable=yes,scrollbars=no,status=yes";
//     var isValidUrl = Util.sanitizeURL(params);
//     if (!isValidUrl) {
//       return false;
//     }

//     window.open(encodeURI(params), windowName, strWindowFeatures);

//     const requestDataJson = JSON.parse(queryDetail.RequestDataJson);

//     return (
//       <>
//         <div>
//           {requestDataJson !== null ? (
//             <div className="col-md-12 pn5">
//               <p className="serv-titlepsq">
//                 <strong>
//                   <img src="/content/images/address.png" alt="" width="16" />
//                   New Contact
//                 </strong>
//                 {statusCode !== Status.RESOLVED &&
//                   statusCode !== Status.AUTORESOLVED && (
//                     <span
//                       className="prmLink"
//                       onClick={OpenProviderAddressManager()}
//                     >
//                       <a href="#">
//                         <img
//                           src="/content/images/editPRM.png"
//                           alt=""
//                           width="16"
//                         />
//                         Update in Provider Manager
//                       </a>
//                     </span>
//                   )}
//               </p>

//               <div className="updateContactContainer">
//                 {Object.entries(requestDataJson.updatedContactDetails).map(
//                   ([label, value]) =>
//                     value !== null && (
//                       <div key={label}>
//                         <label
//                           style={{
//                             fontWeight: "bold",
//                             textTransform: "capitalize",
//                           }}
//                         >
//                           {label} :
//                         </label>
//                         <span>{value}</span>
//                       </div>
//                     )
//                 )}
//               </div>
//             </div>
//           ) : null}
//         </div>
//       </>
//     );
//   };
// };

// // export default ContactChangeRequest;
