import { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ActionTypes, FieldNames } from "../Store/Constants";
import { getMemoizedState } from "../Store/Selectors";
// import "../css/sample.css";
// import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
// import "../../node_modules/bootstrap/dist/js/bootstrap.min.js";
// import "../../node_modules/jquery/dist/jquery.min.js";
// import "../../public/css/bootstrap.min.css";
// import "../../public/js/bootstrap.min.js";
import "../css/providerrequest.css";

export const CallTracker = () => {
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [counterStart, setCounterStart] = useState(false);

  const { CallId, IsAutoCallStop } = useSelector(getMemoizedState);

  const dispatch = useDispatch();

  const clearIntervalRef = useRef(null);
  const prevCallIdRef = useRef("");
  const actions = {
    initServerCall: (action, data) =>
      dispatch({
        type: ActionTypes.INIT_SERVERCALL,
        payload: { action: action, data },
      }),
    updateRequestField: (field, data) =>
      dispatch({
        type: ActionTypes.UPDATE_REQUEST_FIELD,
        payload: { field: field, data: data },
      }),
  };

  //componentDidMount()
  useEffect(() => {
    console.log("Mounted -calltracker   ");
    const time = localStorage.getItem("time");
    const callId = localStorage.getItem("callId");

    if (time && callId) {
      const parsedTime = JSON.parse(time);
      const { hours, minutes, seconds } = { ...parsedTime };
      console.log("Time", hours, minutes, seconds);
      actions.initServerCall(ActionTypes.STOP_CALL, {
        time: `${hours.toString().padStart(2, "0")}: ${minutes
          .toString()
          .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
        callId,
        IsAutoCallStop: true,
      });
    }
  });

  useEffect(() => {
    if (
      prevCallIdRef.current === "" &&
      CallId !== "" &&
      !IsAutoCallStop &&
      !counterStart
    ) {
      prevCallIdRef.current = CallId;
      onStartCounter();
    }
  }, [CallId, IsAutoCallStop, counterStart]);

  const setTimerInLocalStorage = () => {
    localStorage.setItem(
      "time",
      JSON.stringify({
        hours,
        minutes,
        seconds,
      })
    );
  };

  const changeCounter = () => {
    if (counterStart) {
      if (seconds === 59) {
        setSeconds(0);
        setMinutes((prevMinutes) => prevMinutes + 1);
        setTimerInLocalStorage();
      } else if (minutes === 59) {
        setSeconds(0);
        setMinutes(0);
        setHours((prevHours) => prevHours + 1);
        setTimerInLocalStorage();
      } else {
        setSeconds((prevSeconds) => prevSeconds + 1);
        setTimerInLocalStorage();
      }
    }
  };

  const onStartCounterApiCall = () => {
    console.log("Start call ");
    actions.initServerCall(ActionTypes.START_CALL);
  };

  const onStartCounter = () => {
    setCounterStart(true);
    if (clearIntervalRef.current) {
      clearInterval(clearIntervalRef.current);
    }
    let interval = setInterval(() => {
      changeCounter();
    }, 1000);

    clearIntervalRef.current = interval;
  };

  const onStopCounter = () => {
    console.log("OnStopCounter!");
    actions.initServerCall(ActionTypes.STOP_CALL, {
      time: `${hours.toString().padStart(2, "0")}:${minutes
        .toString()
        .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
    });
    setCounterStart(false);
    setHours(0);
    setMinutes(0);
    setSeconds(0);
  };

  const onChangeCallHistoryOption = (value) => {
    console.log("OnChangeHistory!");
    actions.updateRequestField(FieldNames.ShowCurrentCallRequests, value);
  };

  return (
    <div className="call-tracker-panel">
      {CallId !== "" && (
        <div className="Querytitle">
          <span
            className="pull-right showcall_history"
            onClick={() => {
              onChangeCallHistoryOption(true);
            }}
          >
            <img
              src="/content/images/Current call requests.png"
              alt="Current call requests"
            />
            Current Call Requests
          </span>
        </div>
      )}
      <span className="timer">
        <>
          {hours.toString().padStart(2, "0")}:{" "}
          {minutes.toString().padStart(2, "0")} :{" "}
          {seconds.toString().padStart(2, "0")}
        </>
        {counterStart ? ( //false
          <button //pause
            onClick={onStopCounter}
            // className="pause"
            disabled={!counterStart}
            // className="glyphicon glyphicon-stop timerimg1"
          ></button>
        ) : (
          <button //play
            // className="glyphicon glyphicon-play timerimg"
            onClick={onStartCounterApiCall} //false
            disabled={counterStart}
          ></button>
        )}
      </span>
    </div>
  );
};
