import { useDispatch, useSelector } from 'react-redux'
import { getMemoizedState } from '../Store/Selectors'
import { useEffect, useRef } from 'react'
import {
  ActionFields,
  ActionTypes,
  FieldNames,
  ScreenType,
  Status,
} from '../Store/Constants'
import { SetErrorClass, SetErrorTitle } from '../Common/Actions/FieldData'
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns'
import { RequestCardEdit } from './RequestCardEdit'
import { RequestCard } from './RequestCard'
import { RequestMode } from '../Store/Constants'
// import "../css/sample.css";
import '../css/providerrequest.css'

export const RequestForm = ({ openEditor }) => {
  const {
    requestForm,
    CurrentScreen,
    ActiveQuery,
    WindowHeight,
    MasterData,
    queryDetails,
  } = useSelector(getMemoizedState)

  const dispatch = useDispatch()

  const inputDisabled = requestForm.IsReadOnly //false
  const disableActions =
    requestForm.StatusCode.toUpperCase() === Status.RESOLVED ||
    requestForm.StatusCode.toUpperCase() === Status.AUTORESOLVED

  const actions = {
    openFollowUp: () => {
      dispatch({ type: ActionTypes.OPEN_FOLLOWUP })
    },
    updateScreenState: (screen) => {
      dispatch({ type: ActionTypes.UPDATE_SCREENSTATE, screen })
    },
    updateRequestField: (field, data) =>
      dispatch({
        type: ActionTypes.UPDATE_REQUEST_FIELD,
        payload: { field: field, data: data },
      }),
    initServerCall: (action) =>
      dispatch({
        type: ActionTypes.INIT_SERVERCALL,
        payload: { action: action },
      }),
    onPopUpEditorValueChange: (parameter, data) => {
      dispatch({
        type: parameter.actionType,
        payload: { field: parameter.field, data: data },
      })
    },
  }

  const prevRequestFormCapIdRef = useRef(null)
  const prevScreenRef = useRef(null)
  const callerNameRef = useRef(null)
  const requestDetailsRef = useRef(null)
  const dropDownListObjectRef = useRef(null)

  //ComponentDidUpdate()
  useEffect(() => {
    console.log('ActiveQuery:', ActiveQuery)
    if (prevRequestFormCapIdRef.current !== requestForm.CapId.Value) {
      console.log('prev', prevRequestFormCapIdRef.current)
      if (!requestForm.CapId.Value) {
        // console.log("requestForm:", requestForm);
        console.log('CapId:', requestForm.CapId.Value)
        dropDownListObjectRef.current = null
      } else {
        console.log('CapId:', requestForm.CapId.Value)
        dropDownListObjectRef.current = requestForm.CapId.Value
      }
      prevRequestFormCapIdRef.current = requestForm.CapId.Value
      console.log('previous', prevRequestFormCapIdRef.current)
    }

    //COME BACK
    if (
      prevScreenRef.current !== CurrentScreen &&
      (CurrentScreen === ScreenType.AddForm ||
        CurrentScreen === ScreenType.EditForm)
    ) {
      callerNameRef.current.scrollTop = 0
    }
  })

  const onCloseRequestForm = () => {
    console.log('REQUEST FORM CLOSED')
    if (
      requestForm.HasChanges ||
      window.confirm('Current Changes will be lost. Are you sure to proceed ?')
    ) {
      actions.updateScreenState(ScreenType.Grid)
    }
  }

  const getPanelStyle = () => {
    let objStyle = { width: '0', marginRight: '0px' }
    if (
      CurrentScreen == ScreenType.AddForm ||
      CurrentScreen == ScreenType.EditForm
    )
      objStyle = { width: '60.5%', marginRight: '20px' }
    else if (
      CurrentScreen == ScreenType.AddFormWithHistory ||
      CurrentScreen == ScreenType.EditFormWithHistory
    )
      objStyle = { width: '54%', marginRight: '45%' }

    return objStyle
  }

  const openFollowUp = () => {
    console.log('OpenFollowup')
    if (
      !ActiveQuery.HasChanges ||
      window.confirm(
        'Hello ! Current Changes will be lost. Are you sure to proceed?',
      )
    ) {
      actions.openFollowUp()
    }
  }

  let requestMode = requestForm?.ActiveQuery?.RequestMode?.Value?.toUpperCase()

  return (
    <div id="rightPane_psq_view_details" style={getPanelStyle()}>
      <div className="sticky_head col-md-12 p0">
        <div
          className={
            requestForm.IsAddRequest ? 'col-md-12 pad10' : 'col-md-4 pad10'
          }
        >
          <p className="serv-titlepsq">
            <strong>
              {requestForm.IsAddRequest //filterrow - button - sets TRUE
                ? `Add New Request`
                : `Request Detailed View`}
            </strong>
            {/* {requestForm.IsAddRequest && ( //false */}
            <button
              // className="rightCloseBtn_add closebtn_add closeicon glyphicon glyphicon-remove-circle pull-right"
              // onClick={onCloseRequestForm}
              onClick={openEditor}
            >
              Click
            </button>
            {/* )} */}
          </p>
        </div>
        {/* {!requestForm.IsAddRequest && ( */}
        {!requestForm.IsAddRequest && (
          <>
            <div className="col-md-5 bgclip">
              <div className="reqid">
                Request # {requestForm?.RequestId}
                <span
                  className={`requestStatus ${
                    requestForm?.StatusCode === 'NEW'
                      ? 'statusNew'
                      : requestForm?.StatusCode === 'UNRESOLVED'
                      ? 'statusWIP'
                      : requestForm?.StatusCode === 'REOPENED'
                      ? 'statusReopen'
                      : 'statusRes'
                  }`}
                >
                  {requestForm?.StatusName}
                </span>
              </div>
            </div>
            <div className="col-md-3 pad10">
              <p className="followupbtn">
                {!requestForm.IsReadOnly ? ( //changed
                  requestMode !== RequestMode.PORTAL ? (
                    <span className="followupssection" onClick={openFollowUp}>
                      {/* // <span className="followupssection"> */}
                      <img src="/content/images/Followup.png" alt="" />
                      Add Follow up
                    </span>
                  ) : null
                ) : null}
                {/* <span
                  onClick={onCloseRequestForm}
                  className="rightCloseBtn_view closeicon glyphicon glyphicon-remove-circle pull-right"
                ></span> */}
                <button
                  onClick={onCloseRequestForm}
                  // className="rightCloseBtn_view pull-right closeicon"
                ></button>
              </p>
            </div>
          </>
        )}
      </div>
      <div className="col-md-12 p0">
        <div
          className="col-md-4 view_form_elements"
          style={{
            height: requestForm.IsReadOnly
              ? WindowHeight - 257
              : WindowHeight - 306,
          }}
          ref={callerNameRef}
        >
          <div className="seg_section seg_section_bdr">
            <h4 className="seg_title">Caller Information</h4>
            <div className="form-group">
              <label>Caller Name*</label>
              <input
                type="text"
                value={requestForm?.CallerName.Value}
                maxLength={100}
                title={SetErrorTitle(requestForm.CallerName)}
                className={SetErrorClass(requestForm.CallerName)}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.CallerName,
                    e.target.value,
                  )
                }
                disabled={inputDisabled}
              ></input>
            </div>
            <div className="form-group">
              <label>
                Caller Number
                {requestForm.IsCallerNumberRequired ? '*' : ''}
              </label>
              <input
                type="text"
                value={requestForm?.CallerNumber.Value}
                placeholder="Phone"
                maxLength={50}
                title={SetErrorTitle(requestForm.CallerNumber)}
                className={SetErrorClass(requestForm.CallerNumber)}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.CallerNumber,
                    e.target.value,
                  )
                }
                disabled={inputDisabled}
              ></input>
            </div>
            <div className="form-group">
              <label>Outreach Contact</label>
              <input
                type="text"
                value={requestForm?.OutreachContact.Value}
                placeholder="Email or Phone"
                maxLength={100}
                title={SetErrorTitle(requestForm.OutreachContact)}
                className={SetErrorClass(requestForm.OutreachContact)}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.OutreachContact,
                    e.target.value,
                  )
                }
                disabled={inputDisabled}
              ></input>
            </div>
            <div className="form-group">
              <label>
                Requester Email{requestForm.IsEmailRequired ? '*' : ''}
              </label>
              <input
                type="text"
                value={requestForm?.RequesterMail.Value}
                placeholder="Email"
                maxLength={100}
                title={SetErrorTitle(requestForm.RequesterMail)}
                className={SetErrorClass(requestForm.RequesterMail)}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.RequesterMail,
                    e.target.value,
                  )
                }
                disabled={inputDisabled}
              ></input>
            </div>
          </div>
          <div className="eg_section seg_section_bdr">
            <h4 className="seg_title">Basic Information</h4>
            <div className="form-group">
              <label>Request Type*</label>
              <select
                name="Request Type"
                title={SetErrorTitle(requestForm.RequestTypeId)}
                className={SetErrorClass(requestForm.RequestTypeId)}
                id="SelReqType"
                value={requestForm?.RequestTypeId.Value}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.RequestTypeId,
                    e.target.value,
                  )
                }
                disabled={inputDisabled}
              >
                <option>-Select-</option>
                {MasterData.RequestTypes.map((option) => {
                  if (
                    !requestForm.IsAddRequest ||
                    option.ShowIn.includes('MINE')
                  ) {
                    return (
                      <option key={option.Id} value={option.Id}>
                        {option.Name}
                      </option>
                    )
                  }
                })}
              </select>
            </div>
            <div className="form-group">
              <label>Client Audit Program</label>
              <DropDownListComponent
                ref={dropDownListObjectRef}
                className="form-control"
                dataSource={MasterData?.CapDetails}
                filterType="Contains"
                allowFiltering={true}
                filterBarPlaceholder={'Search'}
                fields={{
                  text: 'ClientAuditProgramName',
                  value: 'ClientAuditProgramId',
                }}
                value={requestForm?.CapId.Value}
                placeholder={'Select'}
                onChange={(e) => {
                  if (e.isInteracted) {
                    actions.updateRequestField(FieldNames.CapId, e.value)
                  }
                }}
                enabled={!inputDisabled}
                cssClass={!inputDisabled ? 'cap-ddl' : 'cap-ddl-disabled'}
              />
            </div>
            <div className="form-group">
              <label>Audit ID</label>
              <input
                type="text"
                value={requestForm?.AuditId.Value}
                maxLength={10}
                title={SetErrorTitle(requestForm.AuditId)}
                className={SetErrorClass(requestForm.AuditId)}
                onChange={(e) =>
                  actions.updateRequestField(FieldNames.AuditId, e.target.value)
                }
                onBlur={(e) =>
                  actions.updateRequestField(FieldNames.AuditId_OnBlur)
                }
                disabled={inputDisabled}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    actions.updateRequestField(FieldNames.AuditId_OnBlur)
                  }
                }}
              ></input>
            </div>
            <div className="form-group">
              <label>Additional Audit Id's</label>
              <textarea
                disabled={inputDisabled}
                rows="2"
                title={SetErrorTitle(requestForm.AdditionalAuditIds)}
                className={SetErrorClass(requestForm.AdditionalAuditIds)}
                value={requestForm?.AdditionalAuditIds.Value}
                onBlur={(e) =>
                  actions.updateRequestField(
                    FieldNames.AdditionalAuditId_OnBlur,
                  )
                }
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.AdditionalAuditIds,
                    e.target.value,
                  )
                }
              ></textarea>
            </div>
            <div className="form-group">
              <label>Flow Name</label>
              <p>{requestForm?.FlowName}</p>
            </div>
          </div>
          <div className="seg_section">
            <h4 className="seg_title">Provider/Patient Information</h4>
            <div className="form-group">
              <label>Provider Name</label>
              <p>{requestForm?.ProviderName}</p>
            </div>
            <div className="form-group">
              <label>Patient Name</label>
              <p>{requestForm?.PatientName}</p>
            </div>
            <div className="form-group">
              <label>Provider Address</label>
              <p>{requestForm?.ProviderAddress}</p>
            </div>
          </div>
        </div>
        <div
          ref={requestDetailsRef}
          className="col-md-8 right_section"
          style={{
            height: requestForm.IsReadOnly
              ? WindowHeight - 257
              : WindowHeight - 306,
          }}
        >
          {/* CHANGED */}
          {!requestForm.IsAddRequest && (
            <h3 className="Querytitle mTop10">
              Request Details
              <p className="pull-right">
                <span
                  className="showcall_history mLeft15"
                  onClick={() => {
                    actions.initServerCall(ActionTypes.GET_CALL_HISTORY)
                  }}
                >
                  <img src="content/images/Call history.png" alt="" /> Call
                  History
                </span>
              </p>
            </h3>
          )}

          <div className="clearFix">
            {/* {ActiveQuery?.ShowEditCard && <RequestCardEdit />}
            {queryDetails
              ?.filter((queryDetail) => queryDetail?.Id !== ActiveQuery?.Id)
              .map((queryDetail) => (
                <RequestCard
                  key={queryDetail.Id}
                  queryDetail={queryDetail}
                  requestDetailsRef={requestDetailsRef}
                />
              ))} */}
          </div>
        </div>
      </div>
      {requestForm.IsReadOnly ? null : (
        <div className="sticky_footer">
          {/* CHANGED -- */}
          {requestForm.IsAddRequest && (
            <>
              <input
                type="checkbox"
                checked={requestForm?.IsAddAnother}
                onChange={(e) =>
                  actions.updateRequestField(
                    FieldNames.IsAddAnother,
                    e.target.checked,
                  )
                }
                style={{ marginRight: '5px' }}
              />
              <label className="mar-1-5">Add another</label>
            </>
          )}
          {/* CHANGED */}
          {!requestForm.IsAddRequest && (
            <button
              className="btn btn-sm btn-primary mLeft15 mRight5"
              onClick={() => actions.initServerCall(ActionFields.NEW_REQUEST)}
            >
              New Request
            </button>
          )}
          <button
            className="btn btn-sm btn-primary mRight5"
            onClick={() => actions.initServerCall(ActionFields.RESOLVED)}
            disabled={disableActions}
          >
            Resolved
          </button>
          <button
            className="btn btn-sm btn-primary mRight5"
            onClick={() => actions.initServerCall(ActionFields.UNRESOLVED)}
            disabled={
              disableActions ||
              requestForm.StatusCode.toUpperCase() === Status.UNRESOLVED
            }
          >
            Unresolved
          </button>
          {!requestForm.IsAddRequest && (
            <button
              className="btn btn-sm btn-primary mRight5"
              onClick={() => actions.initServerCall(ActionFields.SAVE)}
              disabled={disableActions}
            >
              Save
            </button>
          )}
          <button
            className="btn btn-sm btn-primary mRight5"
            onClick={() => actions.initServerCall(ActionFields.RESET)}
            disabled={disableActions}
          >
            Reset
          </button>
        </div>
      )}
    </div>
  )
}
