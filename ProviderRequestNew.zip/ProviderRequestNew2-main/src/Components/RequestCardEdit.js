import { useSelector, useDispatch } from "react-redux";
import { getMemoizedState } from "../Store/Selectors";
import { Util } from "../Common/Actions/Util";
import {
  RequestMode,
  FieldNames,
  RequestTypeCode,
  ActionTypes,
} from "../Store/Constants";
import { useEffect, useState, useRef, forwardRef } from "react";
// import ReactHtmlParser from "react-html-parser";
import HTMLReactParser from "html-react-parser";
import { ContactChangeRequest } from "./ContactChangeRequest";
import { SetErrorClass, SetErrorTitle } from "../Common/Actions/FieldData";
// import "../css/sample.css";
import "../css/providerrequest.css";
import PopUpTextEditor from "../Common/Components/PopUpTextEditor";

export const RequestCardEdit = ({ openEditor }) => {
  const [verifiedUsing, setVerifiedUsing] = useState([
    { text: "Audit Id", checked: false, name: "Audit Id" },
    { text: "Patient Info", checked: false, name: "Patient Info" },
    { text: "Facility Info", checked: false, name: "Facility Info" },
    { text: "Claim Number", checked: false, name: "Claim Number" },
  ]);

  const popUpEditorRef = useRef(null);

  const {
    ActiveQuery,
    MasterData,
    requestForm,
    CallerInformation,
    CallId,
    PreviousQueryDetails,
    queryDetails,
    isClicked,
  } = useSelector(getMemoizedState);

  const dispatch = useDispatch();

  const actions = {
    updateActiveQueryField: (field, data) =>
      dispatch({
        type: ActionTypes.UPDATE_ACTIVE_QUERY,
        payload: { field: field, data: data },
      }),
  };

  const renderVerifiedUsing = () => {
    let verified_using = [];
    console.log("Verified:", ActiveQuery.VerifiedUsing.Value);
    if (ActiveQuery?.VerifiedUsing.Value) {
      console.log("Render method...");
      verified_using = ActiveQuery?.VerifiedUsing.Value.split(",");
      console.log("verifiedUsing:", verified_using);
    } else {
      // verified_using = verifiedUsing;
      console.log("verifiedUsing from else:", verified_using);
    }
    const updatedVerifiedUsing = [...verifiedUsing];
    updatedVerifiedUsing.map((el) => {
      el.checked = false;
      verifiedUsing.map((element) => {
        console.log(typeof element);
        console.log("Element:", element);
        if (el.name.toLowerCase().trim() === element.toLowerCase().trim()) {
          const index = updatedVerifiedUsing.findIndex(
            (option) =>
              option.name.toLowerCase().trim() === el.name.toLowerCase().trim()
          );
          updatedVerifiedUsing[index].checked = true;
        }
      });
    });
    const defaultState = verifiedUsing.map((elem) => {
      return {
        ...elem,
        checked: false,
      };
    });
    setVerifiedUsing((prevState) => {
      return {
        ...prevState,
        verifiedUsing:
          ActiveQuery?.VerifiedUsing.Value === ""
            ? defaultState
            : updatedVerifiedUsing,
      };
    });
  };
  // MOUNT;
  // useEffect(() => {
  //   console.log("Useeffect called...");
  //   renderVerifiedUsing();
  // }, [ActiveQuery.VerifiedUsing]);

  const prevActiveQueryIdRef = useRef(null);
  const prevActiveQueryVerifiedRef = useRef(null);

  //UPDATE
  useEffect(() => {
    if (
      ActiveQuery.Id !== prevActiveQueryIdRef.current ||
      ActiveQuery.HasChanges ||
      ActiveQuery.VerifiedUsing.Value !== prevActiveQueryVerifiedRef.current
    ) {
      renderVerifiedUsing();
    }
  }, [ActiveQuery]);

  const onChangeVerifiedUsing = (event) => {
    const { name, checked } = event.target;
    const updatedVerifiedUsing = [...verifiedUsing];
    console.log("updated:", updatedVerifiedUsing);
    const index = updatedVerifiedUsing.findIndex(
      (option) => option.name === name
    );
    updatedVerifiedUsing[index].checked = checked;
    setVerifiedUsing((prevState) => {
      return {
        ...prevState,
        verifiedUsing: updatedVerifiedUsing,
      };
    });
    // console.log(VerifiedUsing)
    console.log("Set:", verifiedUsing);
    const checkedOptions = updatedVerifiedUsing
      .filter((option) => option.checked)
      .map((option) => option.name);
    actions.updateActiveQueryField(
      FieldNames.VerifiedUsing,
      checkedOptions.join(", ")
    );
    console.log("Checked:", checkedOptions);
  };

  const getRequestMode = () => {
    if (requestForm.IsAddRequest || ActiveQuery.IsFollowUp) {
      //exclude portal mode for new request
      console.log("isFollowUp:", ActiveQuery.IsFollowUp);
      return MasterData.RequestMode.filter((x) => x.toLowerCase() !== "portal");
    } else {
      return MasterData.RequestMode;
    }
  };

  const handleClick = () => {
    isClicked = true;
  };

  let requestMode = ActiveQuery?.RequestMode?.Value?.toUpperCase();
  let requestTypeCode = requestForm?.RequestTypeCode;

  return (
    <>
      <div className="detailsCard" id="">
        <div className="textdetails1">
          <h3 className="detailsCardheader">
            {requestForm.IsAddRequest
              ? "Add Query"
              : ActiveQuery.IsFollowUp //changed
              ? Util.getCustomDateTimeFormat(ActiveQuery?.AttendedAt)
              : "New Follow Up"}
            {!requestForm.IsAddRequest && (
              <span className="pull-right ronlytxt">
                {ActiveQuery?.AttendedByFullName}
              </span>
            )}
          </h3>
          <div className="col-md-12 mBot10 Authparam mTop10">
            <div className="form-group">
              <label>Channel*:</label>
              <select
                name="Request Mode"
                disabled={CallId && !ActiveQuery.Id}
                title={SetErrorTitle(ActiveQuery.RequestMode)}
                className={SetErrorClass(ActiveQuery.RequestMode)}
                id="SelReqType"
                value={ActiveQuery?.RequestMode?.Value}
                onChange={(e) =>
                  actions.updateActiveQueryField(
                    FieldNames.RequestMode,
                    e.target.value
                  )
                }
              >
                {getRequestMode().map((option) => {
                  return (
                    <option key={option} value={option} defaultValue="Phone">
                      {option}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
          {requestMode != RequestMode.PORTAL && (
            <div className="col-md-12 Authparam">
              <div className="form-group">
                <label>
                  Requester Verified Using
                  {/* false */}
                  {requestForm.IsVerifiedUsingRequired ? "*" : ""}:{" "}
                </label>
                <p>
                  {verifiedUsing.map((option) => {
                    return (
                      <span className="checkboxparam" key={option.name}>
                        <input
                          type="checkbox"
                          title={SetErrorTitle(ActiveQuery.VerifiedUsing)}
                          name={option.name}
                          checked={option.checked}
                          onChange={onChangeVerifiedUsing}
                        />
                        {option.text}
                      </span>
                    );
                  })}
                </p>
              </div>
            </div>
          )}

          {requestMode == RequestMode.PORTAL &&
            requestTypeCode == RequestTypeCode.ADDRESS_CHANGE_REQUEST && (
              <ContactChangeRequest
                queryDetail={queryDetails[0]}
                statusCode={requestForm.StatusCode}
              />
            )}

          <div className="col-md-12 pn5">
            <div className="form-group">
              <span className="Icnclr">
                <img
                  className="v_align_bot mb5"
                  src="/content/images/query.png"
                  alt=""
                />
              </span>
              <label>Query*</label>&nbsp;
              {requestMode == RequestMode.EMAIL &&
              ActiveQuery?.DisableQueryWindow === true ? (
                <span title="Email Query cannot be modified">
                  <div
                    className="glyphicon glyphicon-edit grid-action-img"
                    onClick={handleClick}
                  ></div>
                </span>
              ) : (
                <span
                  title="Edit in popup"
                  onClick={() =>
                    openEditor("Query", ActiveQuery?.Query?.Value, {
                      field: FieldNames.Query,
                      actionType: ActionTypes.UPDATE_ACTIVE_QUERY,
                    })
                  }
                >
                  <span className="glyphicon glyphicon-edit"></span>
                </span>
              )}
              {CallId !== "" && PreviousQueryDetails.Query !== "" && (
                <span
                  class="copyPrev"
                  onClick={() => {
                    actions.updateActiveQueryField(
                      FieldNames.CopyPreviousQuery,
                      PreviousQueryDetails.Query
                    );
                  }}
                >
                  <img class="" src="/content/images/qr-copy.png" alt="" /> Copy
                  Previous Query
                </span>
              )}
              {requestMode == RequestMode.EMAIL &&
              ActiveQuery?.DisableQueryWindow === true ? (
                <div className="col-md-11 p0 right_section query_section">
                  <p className="txtQuery">
                    {HTMLReactParser(ActiveQuery?.Query?.Value)}
                  </p>
                </div>
              ) : (
                <textarea
                  name=""
                  id=""
                  cols="30"
                  rows="4"
                  maxLength={2000}
                  title={SetErrorTitle(ActiveQuery.Query)}
                  className={SetErrorClass(
                    ActiveQuery.Query,
                    "w100 bdr_dashed"
                  )}
                  value={ActiveQuery?.Query?.Value}
                  onChange={(e) =>
                    actions.updateActiveQueryField(
                      FieldNames.Query,
                      e.target.value
                    )
                  }
                >
                  {ActiveQuery?.Query?.Value}
                </textarea>
              )}
            </div>
          </div>
          <div className="col-md-12 response">
            <div className="form-group">
              <span className="Icnclr">
                <img
                  className="v_align_bot mb5"
                  src="/content/images/response.png"
                  alt=""
                />
              </span>
              <label>
                Response
                {requestForm.IsResponseRequired ? "*" : ""}
              </label>
              &nbsp;
              <span
                title="Edit in popup"
                onClick={() =>
                  openEditor("Response", ActiveQuery?.Response?.Value, {
                    field: FieldNames.Response,
                    actionType: ActionTypes.UPDATE_ACTIVE_QUERY,
                  })
                }
              >
                <span className="glyphicon glyphicon-edit"></span>
              </span>
              {CallId !== "" && PreviousQueryDetails.Response !== "" && (
                <span
                  class="copyPrev"
                  onClick={() => {
                    actions.updateActiveQueryField(
                      FieldNames.CopyPreviousResponse,
                      PreviousQueryDetails.Response
                    );
                  }}
                >
                  <img class="" src="/content/images/qr-copy.png" alt="" /> Copy
                  Previous Response
                </span>
              )}
              <span className="pull-right text-merun">
                Don't enter PHI details
              </span>
              <textarea
                name=""
                id=""
                cols="30"
                rows="4"
                maxLength={2000}
                title={SetErrorTitle(ActiveQuery.Response)}
                className={SetErrorClass(
                  ActiveQuery.Response,
                  "w100 bdr_dashed"
                )}
                value={ActiveQuery?.Response?.Value}
                onChange={(e) =>
                  actions.updateActiveQueryField(
                    FieldNames.Response,
                    e.target.value
                  )
                }
              ></textarea>
            </div>
          </div>
        </div>

        {/* <PopUpTextEditor
          popUpKey="popupTextEditor"
          ref={popUpEditorRef}
          onValueUpdate={actions.onPopUpEditorValueChange}
        /> */}
      </div>
    </>
  );
};
