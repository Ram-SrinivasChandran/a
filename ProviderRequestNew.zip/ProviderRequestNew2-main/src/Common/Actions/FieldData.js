export default class FieldData {
  constructor(value = "", error = "") {
    if (!value) {
      value = "";
    }
    this.Value = value;
    this.Error = error;
  }
}

//Set Value and clear Error
export const SetValue = (field, value) => {
  field.Value = value;
  field.Error = "";
};

export const SetErrorTitle = (fieldData) => {
  if (
    fieldData != null &&
    fieldData.Error != null &&
    fieldData.Error.length > 0
  )
    return fieldData.Error;
  else return "";
};

export const SetErrorClass = (fieldData, fieldCssClass = "form-control") => {
  if (
    fieldData != null &&
    fieldData.Error != null &&
    fieldData.Error.length > 0
  )
    return fieldCssClass + " has-error-inside";
  else return fieldCssClass;
};

export const SetErrorClassWithMandatory = (fieldData, isMandatory = true) => {
  if (isMandatory) {
    return SetErrorClass(fieldData, "form-control mandatoryField");
  }
  return SetErrorClass(fieldData, "form-control");
};

export const CharRestriction = {
  HandleKeyDown: (RegExPattern, event) => {
    if (
      !RegExPattern.test(event.key) &&
      !(
        event.key === "Tab" ||
        event.key === "Backspace" ||
        event.key === "Control" ||
        event.key === "c" ||
        event.key === "v"
      )
    ) {
      event.preventDefault();
    }
  },
  HandlePaste: (RegExPattern, event) => {
    let pastedValue = event.clipboardData.getData("text/plain");
    if (!RegExPattern.test(pastedValue)) event.preventDefault();
  },
  HandleDrop: (RegExPattern, event) => {
    let droppedValue = event.dataTransfer.getData("text/plain");
    if (!RegExPattern.test(droppedValue)) event.preventDefault();
  },
};
