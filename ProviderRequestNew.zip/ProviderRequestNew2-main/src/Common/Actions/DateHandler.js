
// 1. Create a new date from yyyy-mm-dd string


export const isValidDate = d => (d instanceof Date && !isNaN(d))
export const newDate = (d, s) => {
    let ms_per_minute = 60000;
    
    let ed = new Date(d);
    if(isValidDate(ed))
    {
        ed.setTime( ed.getTime() + ed.getTimezoneOffset() * ms_per_minute );
        let month = String(ed.getMonth() + 1).padStart(2, '0');
        let day = String(ed.getDate()).padStart(2, '0');
        let year = ed.getFullYear();
        d = year + '-' + month + '-' + day;
    }
    else if ((typeof d === 'string' || d instanceof String) && d.length > 0)
    {
        let sAr = d.split('-')
        if(sAr.length === 3)
        {
            let yv = sAr[0];
            let mv= sAr[1];
            let dtv = sAr[2];
            ed = new Date(mv+'/'+dtv+'/'+yv);
            //ed.setDate(dtv); ed.setMonth(mv); ed.setFullYear(yv);  
            ed.setTime( ed.getTime() + ed.getTimezoneOffset() * ms_per_minute );

        }
        else
        {
            let sAd = d.split('/')
            if(sAd[0].length === 4)
            {
                let yva = sAd[0];
                let mva= sAd[1];
                let dtva = sAd[2];
                ed = new Date(mva+'/'+dtva+'/'+yva);
            }
            else
            {
                let yva = sAd[2];
                let mva= sAd[0];
                let dtva = sAd[1];
                ed = new Date(mva+'/'+dtva+'/'+yva);
                ed.setTime( ed.getTime() + ed.getTimezoneOffset() * ms_per_minute );
            }
        }
       
    }
    return ed;
}

export const  GetAddedDate = (dt, nods) =>{
    if(dt === '')
    {
        return '';
    }

    let ED = new Date(dt);
    ED.setDate(ED.getDate() + nods);
    return ED.getFullYear() + '-' + pad((ED.getMonth() + 1),2) + '-' + pad(ED.getDate(),2)  ; 
}

export const  GetSixtyDaysOffDate = (dt) =>{
    let ED = new Date(dt);
    ED.setDate(ED.getDate() + 59);
    return ED.getFullYear() + '/' + pad((ED.getMonth() + 1),2) + '/' + pad(ED.getDate(),2)  ; 
}
export const  GetTwoHundredDaysOffDate = (dt) =>{
    let ED = new Date(dt);
    ED.setDate(ED.getDate() + 199);
    return ED.getFullYear() + '/' + pad((ED.getMonth() + 1),2) + '/' + pad(ED.getDate(),2)  ; 
}

export const  shortMonths = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
];
export const  shortMonthsEndDays = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
];


export const shortDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export const pad = (num, size) => {
    var s = "000000000" + num;
    return s.substr(s.length-size);
  }

  
  export const GetFormattedDateHyphan = (date) => {
    let dateObj = new Date(date); 
    let month = String(dateObj.getMonth() + 1).padStart(2, '0');
    let day = String(dateObj.getDate()).padStart(2, '0');
    let year = dateObj.getFullYear();
    return year + '-' + month + '-' + day;
}

export const GetChangedDate = (s) =>
{
    if(s === undefined) s = "2020-08-01"
    let sAr = s.split('-')
    if(sAr.length === 3 && sAr[0].length === 4)
    {
    let yv = sAr[0];
    let mv= sAr[1];
    let dtv = sAr[2];
    return yv + '/' + mv + '/' + dtv;
    }
    else 
    return s;
}

export const GetUnChangedDate = (s) =>
{
    if(s === undefined || s === "" ) return "2020/08/01";
    let sAr = s.split('/')
    let yv = sAr[0];
    let mv= sAr[1];
    let dtv = sAr[2];
    return yv + '-' + mv + '-' + dtv ;
}


export const GetFormattedDate = (date, separator) => {
    let dateObj = new Date(date);
    let month = String(dateObj.getMonth() + 1).padStart(2, '0');
    let day = String(dateObj.getDate()).padStart(2, '0');
    let year = dateObj.getFullYear();
    switch(separator)
    {
        case '':
            return year + month  + day;
        case '-':
            return year + '-' + month + '-' + day;
        case '`':
            return year + '/' + month + '/' + day;
        default:
            return month + '/' + day + '/' + year;
    }
}

export const GetFormattedDateWithSlash = (date) => {

    let dateObj = new Date(date);

    let month = String(dateObj.getMonth() + 1).padStart(2, '0');
    let day = String(dateObj.getDate()).padStart(2, '0');
    let year = dateObj.getFullYear();


    return year + '/' + month + '/' + day;

}

export const GetDateObjectFromServerFormat = (value) => { 
    if(/\/Date\((\d*)\)\//.test(value))
        return new Date(parseInt(value.replace("/Date(", "").replace(")/",""), 10))
    return value;
}

export const GetFormattedFileName = (prefix,suffix) => { 
    let padValue = (value) => (value < 10) ? "0" + value : value;
    let newDate = new Date();
    let year = newDate.getFullYear();
    let Month = padValue(newDate.getMonth() + 1);
    let Day = padValue(newDate.getDate());
    let Hour = newDate.getHours();
    let Minute = padValue(newDate.getMinutes());
    return (prefix + year + '_' + Month  + '_' + Day + '-' + Hour + '_' + Minute + suffix);
}

export const GetFormattedDateTime = (date) => {
   let padValue = (value) => (value < 10) ? "0" + value : value;
    if(date)
    {
        var newDate = new Date(date);

        var sMonth = padValue(newDate.getMonth() + 1);
        var sDay = padValue(newDate.getDate());
        var sYear = newDate.getFullYear();
        var sHour = newDate.getHours();
        var sMinute = padValue(newDate.getMinutes());
        var sAMPM = "AM";

        var iHourCheck = parseInt(sHour);

        if (iHourCheck > 12) {
            sAMPM = "PM";
            sHour = iHourCheck - 12;
        }
        else if (iHourCheck === 0) {
            sHour = "12";
        }

        sHour = padValue(sHour);

        return sMonth + "/" + sDay + "/" + sYear + " " + sHour + ":" + sMinute + " " + sAMPM;
    }
    else
        return "";
}

export const GetFormattedFileNameWithDateTime = (prefix,suffix) => { 
    let padValue = (value) => (value < 10) ? "0" + value : value;
    let newDate = new Date();
    let year = newDate.getFullYear();
    let Month = padValue(newDate.getMonth() + 1);
    let Day = padValue(newDate.getDate());
    let Hour = newDate.getHours();
    let Minute = padValue(newDate.getMinutes());
    let Second = padValue(newDate.getSeconds());
    return (prefix + year + '_' + Month  + '_' + Day + '-' + Hour + '_' + Minute + '_' + Second + suffix);
}

export const GetEstDateTimeNow = () => {
    let nowTime = new Date();
    nowTime = new Date(
      nowTime.toLocaleString("en-US", { timeZone: "America/New_York" })
    );
    return nowTime;
  }

export const GetEstDateFromServerFormat = (value) => {
    if(/\/Date\((\d*)\)\//.test(value)) {
        var date = new Date(parseInt(value.replace("/Date(", "").replace(")/",""), 10));
        var estDate = date.toLocaleString("en-US", { timeZone: "America/New_York" });
        return new Date(estDate);
    }
    return value;   
}

export const GetFormattedEstDateTimeFromServerFormat = (value) => {
    if(value)
        return GetFormattedDateTime(GetEstDateFromServerFormat(value));
    
    return '';
}

export const GetFormattedEstDateFromServerFormat = (value) => {
    if(value)
        return GetFormattedDate(GetEstDateFromServerFormat(value), '/');
    
    return '';
}