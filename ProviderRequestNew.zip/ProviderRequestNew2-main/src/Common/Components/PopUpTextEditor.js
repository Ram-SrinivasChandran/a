import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react'
import '../../Common/css/PopUpTextEditor.css'
import { RequestCardEdit } from '../../Components/RequestCardEdit'
import { useSelector } from 'react-redux'
import { getMemoizedState } from '../../Store/Selectors'

const PopUpTextEditor = forwardRef((props, ref) => {
  const { onValueUpdate, popUpKey, onOpenEditor } = props
  const [parameter, setParameter] = useState({})
  const [headerText, setHeaderText] = useState('')
  // const [searchData, setSearchData] = useState("");
  const [inputData, setInputData] = useState('')

  const openPopUpBtn = useRef(null)

  useImperativeHandle(
    ref,
    () => {
      return {
        openEditor(headerText, fieldValue, parameter) {
          console.log('openEditor...')
          // setHeaderText(headerText)
          // setInputData(fieldValue)
          // setParameter(parameter)
          // // openPopUpBtn.click()
          // onOpenEditor(headerText, fieldValue, parameter)
          // // Invoke the callback function to pass the data to the parent component
          // if (onOpenEditor) {
          //   onOpenEditor(headerText, fieldValue, parameter)
          // }
        },
      }
    },
    [],
  )

  const updateValue = (e) => {
    setInputData(e.target.value)
  }

  const onEnterClick = (e) => {
    if (e.keyCode === 13) {
      updateValue(e)
    }
  }

  const onSaveClick = () => {
    if (onValueUpdate) {
      onValueUpdate(parameter, inputData)
    }
  }

  return (
    <>
      <button
        style={{ display: 'none' }}
        ref={openPopUpBtn}
        data-toggle="modal"
        data-backdrop="static"
        data-target={'#popUpTextEditor' + (popUpKey ? popUpKey : '')}
        className="modal fade custom-model"
        role="dialog"
      >
        <div className="modal-dialog modal-lg">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              &times;
            </button>
            <h4 className="modal-title">{headerText}</h4>
          </div>
          <div className="modal-body">
            <textarea
              type="textarea"
              rows={15}
              value={inputData}
              onChange={updateValue}
              onClick={onEnterClick}
            />
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-primary"
              data-dismiss="modal"
            >
              Close
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              data-dismiss="modal"
              onClick={onSaveClick}
            >
              Apply
            </button>
          </div>
        </div>
        {/* <RequestCardEdit openEditor={openEditor} /> */}
      </button>
    </>
  )
})

export default PopUpTextEditor

// export default forwardRef((props, ref) => {
//   ;<PopUpTextEditor {...props} ref={ref} />
// })
