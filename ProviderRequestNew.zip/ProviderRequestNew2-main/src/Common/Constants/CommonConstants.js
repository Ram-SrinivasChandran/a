
export const ToastTypes = {
    Success: 'Success',
    Error: 'Error',
    Warning: 'Warning',
    Information: 'Information'
}
export const ToastProps = {
    Warning : { title: 'Warning!', cssClass: 'e-toast-warning', icon: 'glyphicon glyphicon-warning-sign', timeOut : 10000  },
    Success: { title: 'Success!', cssClass: 'e-toast-success', icon: 'glyphicon glyphicon-ok-circle', timeOut : 10000 },
    Error: { title: 'Error!', cssClass: 'e-toast-danger', icon: 'glyphicon glyphicon-remove-circle' , timeOut : 10000 },
    Information: { title: 'Information!', cssClass: 'e-toast-info', icon: 'glyphicon glyphicon-info-sign' , timeOut : 10000 }
}
export const ActionTypes = {
    SHOW_TOAST: "SHOW_TOAST",
    SET_LOADERSTATE: "SET_LOADERSTATE"
}
